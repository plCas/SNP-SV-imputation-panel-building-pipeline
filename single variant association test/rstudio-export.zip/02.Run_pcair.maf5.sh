#!/bin/bash
#
#SBATCH --job-name=pcair.maf5
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/pcair.maf5.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/pcair.maf5.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=cadreq
#SBATCH --qos=normal-cadre
#SBATCH --cpus-per-task 12


ETH=$1 #pooled


source /home/chengp/miniconda3/etc/profile.d/conda.sh
conda activate GENESIS

DIR=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts

OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/res/$ETH


#02.Run_pcair.maf5.sh
SAMPLE_Anno=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/files/Sample_Annot_$ETH

Rscript --vanilla 02.pcair.maf5.R $OUT_PREFIX.gds $SAMPLE_Anno $OUT_PREFIX


