#!/bin/bash
#
#SBATCH --job-name=assoc_chr
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/assoc_chr.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/assoc_chr.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=cadreq
#SBATCH --qos=high-cadre
#SBATCH --cpus-per-task 8
#SBATCH --array=1-22

ETH=$1 #pooled
CHR=$2
#CHR=$SLURM_ARRAY_TASK_ID

source /home/chengp/miniconda3/etc/profile.d/conda.sh
conda activate GENESIS

DIR=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts

VCF_DIR=/s3buckets/wanpinglee-lab-psom-s3-bucket-01/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/vcfs/$ETH

OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/res/$ETH

Pheno=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_Pheno.34376_pc_updated_status.txt

NULL_MODEL=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/nullModels/$ETH.nullModel.rds
#Rscript --vanilla assoc.R <gds> <pheno> <null.model> <out_prefix> <chr>
Rscript --vanilla $DIR/04.assoc.chr.R $OUT_PREFIX.gds $Pheno $NULL_MODEL $OUT_PREFIX $CHR



