#!/bin/bash
#
#SBATCH --job-name=generate_gds
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/generate_gds.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/generate_gds.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=wleeq
#SBATCH --qos=high-wlee
#SBATCH --cpus-per-task 12

ETH=$1 #pooled


source /home/chengp/miniconda3/etc/profile.d/conda.sh
conda activate GENESIS

DIR=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts

VCF_DIR=/s3buckets/wanpinglee-lab-psom-s3-bucket-01/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/vcfs/$ETH

#OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/res/$ETH
OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/res/$ETH


Rscript --vanilla $DIR/01.generate_gds.R $VCF_DIR $OUT_PREFIX
