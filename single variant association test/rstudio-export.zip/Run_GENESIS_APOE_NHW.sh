#!/bin/bash
#
#SBATCH --job-name=GENESIS
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/GENESIS_scripts_new/tmp/GENESIS.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/GENESIS_scripts_new/tmp/GENESIS.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=wleeq
#SBATCH --qos=normal
#SBATCH --cpus-per-task=16
#SBATCH --mem-per-cpu=8G
#SBATCH --array 1-21%1 

source /home/chengp/miniconda3/etc/profile.d/conda.sh
conda activate GENESIS

#CHR=$1
CHR=$SLURM_ARRAY_TASK_ID
PANEL=$1
ETH1=ADGC_NHW
ETH2=NHW

if [ $PANEL = "ADSP"  ];then
	#ADSP
	VCFs=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_plink/vcfs/$ETH1
	OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/res/$ETH2
elif [ $PANEL = "TOPMed" ];then
	#TOPMed
	VCFs=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_plink_TOPMed/vcfs/$ETH1
	OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/res_TOPMed/$ETH2
elif [ $PANEL = "Meta" ];then
	#Meta
	VCFs=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_plink_meta/vcfs/$ETH1
	OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/res_meta/$ETH2
fi

DIR=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/GENESIS_scripts_new
cd $DIR

# step 1
echo "step 1 : 01.generate_gds.R"
if [ ! -f $OUT_PREFIX.gds ];then
	Rscript --vanilla 01.generate_gds.R $VCFs $OUT_PREFIX
fi

# step 2
echo "step 2 : 02.pcair.maf5.R"
SAMPLE_Anno=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/GENESIS_files_new/Sample_Annot_NHW
#Rscript --vanilla pcair.r <GDS> <Sample_Annot File> <Out_Prefix>
#Rscript --vanilla 02.pcair.maf5.R $OUT_PREFIX.gds $SAMPLE_Anno $OUT_PREFIX
#Rscript --vanilla 02.pcair.maf5.rerun.R $OUT_PREFIX.gds $SAMPLE_Anno $OUT_PREFIX

# step 3
echo "step 3 : 03.nullModel.maf5.R"
#Pheno=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_plink/files/ADGC_Pheno.38271_pc.txt
Pheno=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_plink/files/ADGC_Pheno.38271_pc_updated_status.txt
#Rscript --vanilla nullModel.R <GDS> <pcair.rds> <pcrel.rds> <Pheno_file> <out_prefix>
#Rscript --vanilla $DIR/03.nullModel.maf5.adjAPOE.R $OUT_PREFIX.gds $OUT_PREFIX.pcair.rds $OUT_PREFIX.pcrel.rds $Pheno $OUT_PREFIX

# step 4
echo "step 4 : 04.assoc.chr.R"
NULL_MODEL=/qnap-wlee/wanpingleelab/chengp/imputation/assoc_test_GENESIS/res/$ETH2.nullModel.rds
#Rscript --vanilla assoc.R <gds> <pheno> <null.model> <out_prefix> <chr>
#Rscript --vanilla $DIR/04.assoc.chr.R $OUT_PREFIX.gds $Pheno $OUT_PREFIX.nullModel.rds $OUT_PREFIX $CHR
Rscript --vanilla $DIR/04.assoc.chr.R $OUT_PREFIX.gds $Pheno $NULL_MODEL $OUT_PREFIX $CHR


