#!/bin/bash
#
#SBATCH --job-name=bcftools_filter
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/bcftools_filter.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/bcftools_filter.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=wleeq
#SBATCH --qos=normal-wlee
#SBATCH --cpus-per-task 2
#SBATCH --array=1-22


CHR=$SLURM_ARRAY_TASK_ID

ETH=$1 # pooled, ADGC_NHW, ADGC_AA,ADGC_Asian,ADGC_Hispanic

if [[ $ETH == "pooled" ]];then
    SAMPLES=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/pooled_ctr_sample_list
    PC=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/pca/control_sample.pca.txt

elif [[ $ETH == "ADGC_NHW" ]];then
     SAMPLES=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_NHW_ctr_sample_list
     PC=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/pca/ADGC_NHW/ADGC_NHW_ctr_sample.pca.txt

elif [[ $ETH == "ADGC_AA" ]];then
    SAMPLES=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_AA_ctr_sample_list
     PC=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/pca/ADGC_AA/ADGC_AA_ctr_sample.pca.txt

elif [[ $ETH == "ADGC_Asian" ]];then
    SAMPLES=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_Asian_ctr_sample_list
    PC=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/pca/ADGC_Asian/ADGC_Asian_ctr_sample.pca.txt

elif [[ $ETH == "ADGC_Hispanic" ]];then
    SAMPLES=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_Hispanic_ctr_sample_list
    PC=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/pca/ADGC_Hispanic/ADGC_Hispanic_ctr_sample.pca.txt

fi

VCF=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/imputations/IMMerge/ADSP-Short-Var/chr$CHR.ADGC.dose.vcf.gz

OUTDIR=/s3buckets/wanpinglee-lab-psom-s3-bucket-01/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test_hwe/ADSP-Short-Var/vcfs/$ETH
mkdir -p $OUTDIR

ruth=/qnap-wlee/wanpingleelab/chengp/tools/ruth/bin/ruth

bcftools view --threads 2 -S $SAMPLES -i 'R2 > 0.8' $VCF \
    | $ruth --vcf - --evec $PC --field GT --lambda 0 --lrt-em --seed 12345 --out - \
    | bcftools view --threads 2 --drop-genotypes -i 'HWE_SLP_I > -4 && HWE_SLP_I < 4' -Oz -o $OUTDIR/chr$CHR.vcf.gz
bcftools index --threads 2 -t $OUTDIR/chr$CHR.vcf.gz
bcftools stats $OUTDIR/chr$CHR.vcf.gz > $OUTDIR/chr$CHR.vcf.stats

# make ID list
bcftools query -f "%ID" $OUTDIR/chr$CHR.vcf.gz > $OUTDIR/chr$CHR.id_list.txt

