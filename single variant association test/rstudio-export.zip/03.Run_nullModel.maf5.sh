#!/bin/bash
#
#SBATCH --job-name=nullModel.maf5
#SBATCH -o /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/nullModel.maf5.%A_%a.txt
#SBATCH -e /qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts/tmp/nullModel.maf5.error.%A_%a.txt
#SBATCH --ntasks=1
#SBATCH --partition=cadreq
#SBATCH --qos=high-cadre
#SBATCH --cpus-per-task 1


ETH=$1 #pooled


source /home/chengp/miniconda3/etc/profile.d/conda.sh
conda activate GENESIS

DIR=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/scripts

OUT_PREFIX=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/association_test/ADSP-Short-Var/res/$ETH


Pheno=/qnap-wlee/wanpingleelab/chengp/imputation/imputation_panel_12.02.24/ADGC_sample_list/files/ADGC_Pheno.34376_pc_updated_status.txt
#Rscript --vanilla nullModel.R <GDS> <pcair.rds> <pcrel.rds> <Pheno_file> <out_prefix>
Rscript --vanilla $DIR/03.nullModel.maf5.noadjAPOE.R $OUT_PREFIX.gds $OUT_PREFIX.pcair.rds $OUT_PREFIX.pcrel.rds $Pheno $OUT_PREFIX


